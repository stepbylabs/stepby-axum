//! sys_config 模块路由

use std::sync::Arc;
use axum::Router;
use axum::routing::{get, post, put, delete};

use crate::handler::sys_config_handler;
use crate::state::AppState;

pub fn sysConfig_routes() -> Router<Arc<AppState>> {
    Router::new()
        .route("/system/sys_config/list", get(sys_config_handler::list))
        .route("/system/sys_config/{config_id}", get(sys_config_handler::get_info))
        .route("/system/sys_config", post(sys_config_handler::add))
        .route("/system/sys_config", put(sys_config_handler::edit))
        .route("/system/sys_config/{config_id}", delete(sys_config_handler::remove))
}

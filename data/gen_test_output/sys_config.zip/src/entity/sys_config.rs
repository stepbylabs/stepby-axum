//! sys_config 实体定义
//!
//! 

use chrono::NaiveDateTime;
use sea_orm::entity::prelude::*;
use serde::{Deserialize, Serialize};

use crate::common::datetime;

#[derive(Clone, Debug, PartialEq, DeriveEntityModel, Serialize, Deserialize)]
#[sea_orm(table_name = "sys_config")]
#[serde(rename_all = "camelCase")]
pub struct Model {
    #[sea_orm(primary_key)]
    pub config_id: i64,
    pub config_name: Option<String>,
    pub config_key: String,
    pub config_value: Option<String>,
    pub config_type: Option<String>,
    pub create_by: Option<String>,
    pub create_time: Option<Option<chrono::NaiveDateTime>>,
    pub update_by: Option<String>,
    pub update_time: Option<Option<chrono::NaiveDateTime>>,
    pub remark: Option<String>,
}

#[derive(Copy, Clone, Debug, EnumIter, DeriveRelation)]
pub enum Relation {}

#[async_trait::async_trait]
impl ActiveModelBehavior for ActiveModel {}

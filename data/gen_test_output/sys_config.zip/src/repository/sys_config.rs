//! sys_config 数据访问层

use sea_orm::*;

use crate::entity::sys_config::{ActiveModel, Column, Entity as SysConfig, Model};
use crate::repository::base::BaseRepository;

#[derive(Clone)]
pub struct SysConfigRepository {
    base: BaseRepository<SysConfig>,
}

impl SysConfigRepository {
    pub fn new(db: DatabaseConnection) -> Self {
        Self { base: BaseRepository::new(db) }
    }

    pub fn base(&self) -> &BaseRepository<SysConfig> { &self.base }

    pub async fn find_by_id(&self, id: i64) -> Result<Option<Model>, DbErr> {
        SysConfig::find().filter(Column::ConfigId.eq(id)).one(self.base.db()).await
    }

    pub async fn find_all(&self) -> Result<Vec<Model>, DbErr> {
        SysConfig::find().all(self.base.db()).await
    }

    pub async fn insert(&self, model: ActiveModel) -> Result<Model, DbErr> {
        self.base.insert(model).await
    }

    pub async fn update(&self, model: ActiveModel) -> Result<Model, DbErr> {
        self.base.update(model).await
    }

    pub async fn delete_by_id(&self, id: i64) -> Result<DeleteResult, DbErr> {
        SysConfig::delete_many().filter(Column::ConfigId.eq(id)).exec(self.base.db()).await
    }
}

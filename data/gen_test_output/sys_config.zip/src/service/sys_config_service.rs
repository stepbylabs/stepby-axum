//! sys_config 模块 Service 层

use sea_orm::{DatabaseConnection, Set};
use serde::Deserialize;
use validator::Validate;

use crate::common::error::ServiceError;
use crate::entity::sys_config::{ActiveModel, Model};
use crate::repository::sys_config::SysConfigRepository;

pub struct SysConfigService {
    repo: SysConfigRepository,
}

impl SysConfigService {
    pub fn new(db: DatabaseConnection) -> Self {
        Self { repo: SysConfigRepository::new(db) }
    }

    pub async fn get_all(&self) -> Result<Vec<Model>, ServiceError> {
        Ok(self.repo.find_all().await?)
    }

    pub async fn get_by_id(&self, id: i64) -> Result<Model, ServiceError> {
        self.repo.find_by_id(id).await?.ok_or_else(|| ServiceError::not_found("记录不存在"))
    }

    pub async fn create(&self, dto: SysConfigAddDto, operator: &str) -> Result<Model, ServiceError> {
        let now = chrono::Local::now().naive_local();
        let mut am = ActiveModel { ..Default::default() };
        am.config_name = Set(dto.config_name);
        am.config_key = Set(dto.config_key);
        am.config_value = Set(dto.config_value);
        am.config_type = Set(dto.config_type);
        am.create_by = Set(dto.create_by);
        am.create_time = Set(dto.create_time);
        am.update_by = Set(dto.update_by);
        am.update_time = Set(dto.update_time);
        am.remark = Set(dto.remark);
        am.create_by = Set(Some(operator.to_string()));
        am.create_time = Set(Some(now));
        Ok(self.repo.insert(am).await?)
    }

    pub async fn update(&self, dto: SysConfigEditDto, operator: &str) -> Result<Model, ServiceError> {
        let existing = self.get_by_id(dto.config_id).await?;
        let now = chrono::Local::now().naive_local();
        let mut am: ActiveModel = existing.into();
        am.config_name = Set(dto.config_name);
        am.config_key = Set(dto.config_key);
        am.config_value = Set(dto.config_value);
        am.config_type = Set(dto.config_type);
        am.create_by = Set(dto.create_by);
        am.create_time = Set(dto.create_time);
        am.update_by = Set(dto.update_by);
        am.update_time = Set(dto.update_time);
        am.remark = Set(dto.remark);
        am.update_by = Set(Some(operator.to_string()));
        am.update_time = Set(Some(now));
        Ok(self.repo.update(am).await?)
    }

    pub async fn delete(&self, id: i64) -> Result<(), ServiceError> {
        self.repo.delete_by_id(id).await?;
        Ok(())
    }
}

#[derive(Debug, Deserialize, Validate)]
#[serde(rename_all = "camelCase")]
pub struct SysConfigAddDto {
    pub config_name: Option<String>,
    pub config_key: String,
    pub config_value: Option<String>,
    pub config_type: Option<String>,
    pub create_by: Option<String>,
    pub create_time: Option<Option<chrono::NaiveDateTime>>,
    pub update_by: Option<String>,
    pub update_time: Option<Option<chrono::NaiveDateTime>>,
    pub remark: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
#[serde(rename_all = "camelCase")]
pub struct SysConfigEditDto {
    pub config_id: i64,
    pub config_name: Option<String>,
    pub config_key: String,
    pub config_value: Option<String>,
    pub config_type: Option<String>,
    pub create_by: Option<String>,
    pub create_time: Option<Option<chrono::NaiveDateTime>>,
    pub update_by: Option<String>,
    pub update_time: Option<Option<chrono::NaiveDateTime>>,
    pub remark: Option<String>,
}

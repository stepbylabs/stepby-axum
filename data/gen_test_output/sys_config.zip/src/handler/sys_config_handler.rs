//! sys_config 模块 Handler

use std::sync::Arc;
use axum::extract::{Path, State};
use axum::Json;

use crate::common::{AjaxResult, AppError, TableDataInfo};
use crate::middleware::Operator;
use crate::service::sys_config_service::SysConfigService;
use crate::state::AppState;

pub async fn list(State(state): State<Arc<AppState>>) -> Result<TableDataInfo<crate::entity::sys_config::Model>, AppError> {
    let rows = state.sysConfig_service.get_all().await?;
    Ok(TableDataInfo::new(rows.len() as u64, rows))
}

pub async fn get_info(State(state): State<Arc<AppState>>, Path(id): Path<i64>) -> Result<AjaxResult<crate::entity::sys_config::Model>, AppError> {
    let model = state.sysConfig_service.get_by_id(id).await?;
    Ok(AjaxResult::success(model))
}

pub async fn add(State(state): State<Arc<AppState>>, operator: Operator, Json(dto): Json<crate::service::sys_config_service::SysConfigAddDto>) -> Result<AjaxResult<()>, AppError> {
    state.sysConfig_service.create(dto, operator.username()).await?;
    Ok(AjaxResult::success_msg("新增成功"))
}

pub async fn edit(State(state): State<Arc<AppState>>, operator: Operator, Json(dto): Json<crate::service::sys_config_service::SysConfigEditDto>) -> Result<AjaxResult<()>, AppError> {
    state.sysConfig_service.update(dto, operator.username()).await?;
    Ok(AjaxResult::success_msg("修改成功"))
}

pub async fn remove(State(state): State<Arc<AppState>>, Path(id): Path<i64>) -> Result<AjaxResult<()>, AppError> {
    state.sysConfig_service.delete(id).await?;
    Ok(AjaxResult::success_msg("删除成功"))
}

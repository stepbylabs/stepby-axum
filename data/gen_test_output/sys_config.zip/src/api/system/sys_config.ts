import request from '@/utils/request'

// 查询SysConfig列表
export function list(query: any) {
  return request({
    url: '/system/sys_config/list',
    method: 'get',
    params: query
  })
}

// 查询SysConfig详细
export function getSysConfig(id: number) {
  return request({
    url: '/system/sys_config/' + id,
    method: 'get'
  })
}

// 新增SysConfig
export function addSysConfig(data: any) {
  return request({
    url: '/system/sys_config',
    method: 'post',
    data
  })
}

// 修改SysConfig
export function updateSysConfig(data: any) {
  return request({
    url: '/system/sys_config',
    method: 'put',
    data
  })
}

// 删除SysConfig
export function delSysConfig(id: number) {
  return request({
    url: '/system/sys_config/' + id,
    method: 'delete'
  })
}

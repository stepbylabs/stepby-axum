<template>
  <div class="app-container">
    <el-row :gutter="20" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="Plus" @click="handleAdd">新增</el-button>
      </el-col>
    </el-row>

    <el-table v-loading="loading" :data="list">
      <el-table-column label="" prop="configName" />
      <el-table-column label="" prop="configKey" />
      <el-table-column label="" prop="configValue" />
      <el-table-column label="" prop="configType" />
      <el-table-column label="" prop="createBy" />
      <el-table-column label="" prop="createTime" />
      <el-table-column label="" prop="updateBy" />
      <el-table-column label="" prop="updateTime" />
      <el-table-column label="" prop="remark" />
      <el-table-column label="操作" width="180">
        <template #default="scope">
          <el-button type="primary" link icon="Edit" @click="handleEdit(scope.row)">修改</el-button>
          <el-button type="danger" link icon="Delete" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { list, getSysConfig, addSysConfig, updateSysConfig, delSysConfig } from '@/api/system/sys_config'

const loading = ref(false)
const list = ref([])

async function getList() {
  loading.value = true
  try {
    const res = await list({})
    list.value = res.rows || res.data || []
  } finally {
    loading.value = false
  }
}

function handleAdd() {
  // TODO: 打开新增对话框
}

function handleEdit(row: any) {
  // TODO: 打开编辑对话框
}

async function handleDelete(row: any) {
  await delSysConfig(row.configId)
  getList()
}

onMounted(() => {
  getList()
})
</script>

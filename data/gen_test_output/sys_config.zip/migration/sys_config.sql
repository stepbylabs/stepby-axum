-- SysConfig 表结构（仅供参考，实际表结构由数据库元数据导入）
-- 表名: sys_config
-- 描述: 

CREATE TABLE IF NOT EXISTS sys_config (
    config_id INTEGER PRIMARY KEY AUTOINCREMENT,

    config_name varchar(100),

    config_key varchar(100) NOT NULL,

    config_value varchar(255),

    config_type char,

    create_by varchar(64),

    create_time datetime_text,

    update_by varchar(64),

    update_time datetime_text,

    remark varchar(500)

);
